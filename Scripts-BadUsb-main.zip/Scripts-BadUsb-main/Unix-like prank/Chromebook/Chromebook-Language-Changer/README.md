# Chromebook-Language-Changer
https://github.com/RexMan04/Chromebook-Language-Changer
Rubby Ducky prank for chromebooks.
This was designed for a Raspberry Pi Pico, but should work with any ducky as long as you encode it.

This is a prank so when you plug the ducky into the chromebook, it goes it settings, changes the language to Arabic, and deletes the primary language used then closes.

Change the language simply by changing "arabic" to your desired langauge.
