# MacOS Deactivation

This is a fun prank to mimic when a Windows machine is not activated and has a message in the bottom right-hand corner.

It downloads Activate.app from https://github.com/Lakr233/ActivateMac, unzip's it, deletes the zip file (cleanliness is next to godliness), moves it to the Applications folder and runs it.

![](https://github.com/nwhistler/flipper-tools/blob/master/badusb/MacOS/images/activate-macos.png)

Special thanks to [@FalsePhilosopher](https://github.com/FalsePhilosopher) for the idea and [Lakr233](https://github.com/Lakr233/ActivateMac) for the use of the binary.