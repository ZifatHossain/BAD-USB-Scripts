# Forward Email
- Author: Cribbit
- Version: 1.0
- Target: Android 
- Tested on: Samsung S10
- Category: mobile
- Attackmode: HID

## Change Log
| Version | Changes         |
| ------- | --------------- |
| 1.0     | Initial release |

## Description
Forwards the last received email. Included are two versions one for Gmail and Samsung Email app
this was tested on a S10 as there are many flavours of android this many not work on all. Using GUI + E should bring up the default Email app. I have put a comment in for a loop so if you wish to forward more than one email. 

[Hak5 forum post](https://forums.hak5.org/topic/52058-payload-android-phone-forward-email/#comment-329886)

## Configuration
Change `your@email.com` to the email address you wish to send to.