Coleção de scripts para ataques Bad usb.
Cuidado alguns destes scripts pode ser perigosos
