# Original Repo
https://github.com/nocomp/Kiosk-evasion-BADUsb-Bruteforce
# Kiosk-evasion-BADUsb-Bruteforce
Experimental payload script for evade kiosk mode usingg rubber ducky or flipper zero.<br>
<b><h1>If you find other evasion tricks, please open an issue and post them, they ll be added, thank you! </b></h1>
<br>
Run this script first, stop it when evasion is successfull, then run your true payload.<br>
For experimental use only, don t be a dick


