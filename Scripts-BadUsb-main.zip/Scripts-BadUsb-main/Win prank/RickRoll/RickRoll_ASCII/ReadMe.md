Title: RickRoll ASCII<br>
Author:	UberGuidoZ<br>
Original ASCII found online, cleaned it up and made it dance a bit.<br>

Description: Opens Notepad and types out the ASCII art<br>
Notes: When done, payload causes screen to scroll to top and bottom<br>
Target:	Windows but fairly easily modified to work on any OS with a text editor<br>
Version:	1.2<br>
Category:	Prank<br>
Source: https://github.com/UberGuidoZ/OMG-Payloads
