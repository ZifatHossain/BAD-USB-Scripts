# duckNet

## About:
* Title: duckNet
* Description: Create, Encode, Inject, Spread your duckNet and manage it using duckNetManager.
* AUTHOR: drapl0n
* Version: 1.0
* Category: Remote Access
* Target: Unix-like operating systems with systemd.
* Attackmodes: HID

## duckNet is cluster of systems infected with persistentReverseDucky, which are manged by duckNetManager.

### Functions:
* Connect to target.
* Create new target.
* List targets.
* Remove target.
* Update target.

### Installation:
Use ``install.sh`` script to install duckNetManager.

### Usage:
Use command ``duckNetManager``.

#### Support me if you like my work:
* https://twitter.com/drapl0n
