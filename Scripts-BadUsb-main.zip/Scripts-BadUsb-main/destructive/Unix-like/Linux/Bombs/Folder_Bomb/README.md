# prank-or-malware
 **Not recommended to use with strangers, not created for evil use**
 **WITHOUT TEST CASE, DO NOT FORGET THAT THE FILE RUN IN THE BACKGROUND**
 
 
is a totally destructive code to create infinite folders on the PC in a hidden way. ram usage increases a lot with running and after a while the blue screen of death will appear for sure.

- You can turn the file into an executable using the python library "pyinstaller".
- Don't forget to change the directory where the folders will be created. In the code I put standard windows folders, but it's always good to be careful with variables.

This is a exemple of the created folders:
<img src="./result.png">

in my test, an average of 15,000 folders were created in approximately 5 seconds.
