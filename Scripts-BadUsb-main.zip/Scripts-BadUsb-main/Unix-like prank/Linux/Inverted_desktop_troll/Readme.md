VLC works best untill I can figure out how to get aplay to work so I can get the do a barrel roll audio piped to the audio server on all PL's.
